# TapBar
1. Ин файлҳоро ба репозиторийи GitHub бор кунед (branch: main).
2. Tab Actions -> Build APK -> Run workflow (ё танҳо push).
3. Баъди 3-6 дақиқа: run-ро кушоед -> Artifacts -> TapBar-debug-apk -> скачать.
4. ZIP-ро кушоед, app-debug.apk-ро насб кунед.
